﻿namespace DineMaster.DTO
{
    public class MenuCategoryCreateDTO
    {
        public string? CategoryName { get; set; }

        public string? CategoryType { get; set; }

    }
}
