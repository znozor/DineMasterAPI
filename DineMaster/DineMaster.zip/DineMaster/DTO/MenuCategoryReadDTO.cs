﻿namespace DineMaster.DTO
{
    public class MenuCategoryReadDTO
    {
        public int CategoryId { get; set; }
        public string? CategoryName { get; set; }
        public string? CategoryType { get; set; }
    }
}
